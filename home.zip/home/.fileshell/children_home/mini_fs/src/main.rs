use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

fn main() {
    println!("=== 简易文件系统 (mini_fs) - Windows ===");
    println!("输入 help 查看命令列表\n");
    print_current_dir();

    let stdin = io::stdin();
    loop {
        print!("> ");
        io::stdout().flush().unwrap();

        let mut input = String::new();
        if stdin.read_line(&mut input).is_err() {
            break;
        }
        // Windows 下换行可能是 \r\n，trim 会处理
        let input = input.trim();
        if input.is_empty() {
            continue;
        }

        let parts: Vec<&str> = input.split_whitespace().collect();
        let cmd = parts[0].to_lowercase(); // Windows 用户常大小写混用，统一转小写
        let args = &parts[1..];

        match cmd.as_str() {
            "help" | "h" => print_help(),
            "pwd" | "ls" => list_dir(args.get(0).copied()),
            "cd" => change_dir(args.get(0).copied()),
            "mkdir" | "md" => create_dir(args.get(0).copied()),   // 兼容 Windows 的 md
            "touch" | "new" | "type" => create_file(args.get(0).copied()),
            "rm" | "del" | "rmdir" => delete_path(args.get(0).copied()), // 兼容 del/rmdir
            "cat" => cat_file(args.get(0).copied()),
            "echo" => echo_to_file(args),
            "exit" | "quit" | "q" => {
                println!("再见！");
                break;
            }
            _ => println!("未知命令: {}，输入 help 查看帮助", cmd),
        }
    }
}

/// 打印当前工作目录
fn print_current_dir() {
    match env::current_dir() {
        Ok(p) => println!("当前目录: {}", p.display()),
        Err(e) => eprintln!("无法获取当前目录: {}", e),
    }
}

fn print_help() {
    println!(
        r#"可用命令:
  pwd              显示当前目录
  ls [路径]        列出目录内容(默认当前目录)
  cd <路径>        切换目录 (cd .. 返回上级, cd C:\ 切换盘符)
  mkdir <目录名>   创建文件夹 (别名: md)
  touch <文件名>   创建空文件 (别名: new)
  rm <路径>        删除文件或空文件夹 (别名: del, rmdir)
  cat <文件名>     查看文件内容
  echo <文本> > <文件名>  将文本写入文件 (覆盖)
  help             显示帮助
  exit / quit      退出程序"#
    );
}

/// 获取绝对路径（支持相对路径）
/// Windows 上反斜杠和正斜杠都可以, PathBuf 会自动处理
fn resolve_path(path: Option<&str>) -> Option<PathBuf> {
    let p = path?;
    // 处理用户输入时可能带引号的情况: "C:\Program Files"
    let p = p.trim_matches('"').trim_matches('\'').to_string();
    let path_buf = PathBuf::from(p);
    if path_buf.is_absolute() {
        Some(path_buf)
    } else {
        env::current_dir().ok().map(|cwd| cwd.join(path_buf))
    }
}

/// ls：列出目录内容
fn list_dir(path: Option<&str>) {
    let target = match path {
        Some(p) => match resolve_path(Some(p)) {
            Some(p) => p,
            None => return,
        },
        None => env::current_dir().unwrap(),
    };

    if !target.exists() {
        println!("路径不存在: {}", target.display());
        return;
    }
    if !target.is_dir() {
        println!("不是目录: {}", target.display());
        return;
    }

    let mut dirs = Vec::new();
    let mut files = Vec::new();

    match fs::read_dir(&target) {
        Ok(entries) => {
            for entry in entries.flatten() {
                let name = entry.file_name().to_string_lossy().to_string();
                let is_dir = entry.path().is_dir();
                if is_dir {
                    dirs.push(format!("{}\\", name));
                } else {
                    // Windows 上顺便显示文件大小
                    let size = entry.metadata().map(|m| m.len()).unwrap_or(0);
                    files.push(format!("{:>10} B  {}", size, name));
                }
            }
        }
        Err(e) => {
            println!("读取目录失败: {}", e);
            return;
        }
    }

    // 排序便于查看
    dirs.sort();
    files.sort();

    println!("目录: {}", target.display());
    for d in &dirs {
        println!("  [DIR ] {}", d);
    }
    for f in &files {
        println!("  [FILE] {}", f);
    }
    println!("共 {} 个目录, {} 个文件", dirs.len(), files.len());
}

/// cd：切换目录
fn change_dir(path: Option<&str>) {
    let p = match path {
        Some(p) => p,
        None => {
            print_current_dir();
            return;
        }
    };

    let target = match resolve_path(Some(p)) {
        Some(t) => t,
        None => return,
    };

    if !target.exists() {
        println!("目录不存在: {}", p);
        return;
    }
    if !target.is_dir() {
        println!("不是目录: {}", p);
        return;
    }

    // Windows 上 set_current_dir 支持切换盘符，不需要单独 chdir C:
    if let Err(e) = env::set_current_dir(&target) {
        println!("切换目录失败: {}", e);
    } else {
        print_current_dir();
    }
}

/// mkdir：创建文件夹
fn create_dir(name: Option<&str>) {
    let name = match name {
        Some(n) => n,
        None => {
            println!("用法: mkdir <目录名>");
            return;
        }
    };
    // create_dir_all 支持多级: mkdir a\b\c
    match fs::create_dir_all(name) {
        Ok(_) => println!("已创建文件夹: {}", name),
        Err(e) => println!("创建失败: {}", e),
    }
}

/// touch：创建空文件
fn create_file(name: Option<&str>) {
    let name = match name {
        Some(n) => n,
        None => {
            println!("用法: touch <文件名>");
            return;
        }
    };
    match fs::File::create(name) {
        Ok(_) => println!("已创建文件: {}", name),
        Err(e) => println!("创建失败: {}", e),
    }
}

/// rm：删除文件或空文件夹
fn delete_path(name: Option<&str>) {
    let name = match name {
        Some(n) => n,
        None => {
            println!("用法: rm <路径>");
            return;
        }
    };

    let path = Path::new(name);
    if !path.exists() {
        println!("路径不存在: {}", name);
        return;
    }

    // Windows 下如果文件被占用（比如被文本编辑器打开），删除会失败，
    // 这里打印详细错误提示，便于用户定位。
    let result = if path.is_dir() {
        fs::remove_dir(path) // 仅空文件夹
    } else {
        // 清除只读属性（防止 Windows 下因只读属性导致删除失败）
        if let Ok(meta) = fs::metadata(path) {
            let mut perms = meta.permissions();
            if perms.readonly() {
                // set_readonly(false) 在 Windows 和 Linux 上都是稳定且支持的
                perms.set_readonly(false);
                let _ = fs::set_permissions(path, perms);
            }
        }
        fs::remove_file(path)
    };

    match result {
        Ok(_) => println!("已删除: {}", name),
        Err(e) => {
            println!("删除失败: {}", e);
            println!("提示: 文件夹必须为空; 文件可能被其他程序占用或为只读。");
        }
    }
}

/// cat：查看文件内容
fn cat_file(name: Option<&str>) {
    let name = match name {
        Some(n) => n,
        None => {
            println!("用法: cat <文件名>");
            return;
        }
    };
    match fs::read_to_string(name) {
        Ok(content) => print!("{}", content),
        Err(e) => println!("读取失败: {}", e),
    }
}

/// echo 文本 > 文件名
fn echo_to_file(args: &[&str]) {
    if let Some(pos) = args.iter().position(|&s| s == ">") {
        if pos == 0 || pos + 1 >= args.len() {
            println!("用法: echo <文本> > <文件名>");
            return;
        }
        let text = args[..pos].join(" ");
        let file = args[pos + 1];
        // Windows 上写文件用 \r\n 更符合习惯
        match fs::write(file, format!("{}\r\n", text)) {
            Ok(_) => println!("已写入 {} 字节到 {}", text.len() + 2, file),
            Err(e) => println!("写入失败: {}", e),
        }
    } else {
        println!("{}", args.join(" "));
    }
}