#include<bits/stdc++.h>
#include<filesystem>
#include<sys/stat.h>
namespace fs=std::filesystem;
std::string input;
std::string content,s;
std::string normalizePath(std::string path){
    for (char& c:path){
        if (c=='\\') c='/';
    }
    return path;
}
bool fileExists(const std::string& path){
    struct stat buffer;
    return(stat(path.c_str(),&buffer)==0);
}
std::vector<std::string> get_order(std::string order){
    std::string now;std::vector<std::string> res_od;
    for(int i=0;i<(int)order.size();i++){
        if(order[i]==' '){res_od.push_back(now);now="";}
        else now+=order[i];
    }
    res_od.push_back(now);
    return res_od;
}
int main(){
    system("chcp 936");
    printf(R"(=====A SUBSYSTEM(CPP) OF HOMESHELL=====
              ����help �� ��������... )");
    putchar('\n');
    std::string content=fs::current_path().string();
    while(true){
        std::printf("%s> ",content.c_str());
        std::getline(std::cin,input);
        if(input=="exit"){
            system("cls");
            return 0;
        }
        std::vector<std::string> order=get_order(input);
        int length=order.size();
        if(length==0)continue;
        if(order[0]=="help"){
            printf(R"(cd <path> ת��<path>·��
run [doctype] <filename> ([Compile command]) ���ڿɱ������ԣ���[Compile command]�����������[doctype]���͵�<filename>�ļ���
                                             �����������[doctype]���͵�<filename>�ļ���
    [doctype]: -cpp -py -rust ����ӦC++,Python,Rust���ԣ�Rust��ȷ������������rustc.exe��
    <filename>: ����ļ���
    [Compile command]: �������
exit �˳�����ϵͳ
help ��ʾ������
)");
        }
        if(order[0]=="cd"){
            if(length==1 || length==3)continue;
            std::string op;
            try{
                fs::current_path(order[1].c_str());
                content=fs::current_path().string();
            }catch(const fs::filesystem_error& e){
                std::cerr<<"error.cd:"<<e.what()<<std::endl;
            }
        }
        else if(order[0]=="run"){
            if(length==1){
                printf("need what's the doctype to run.\n");
                continue;
            }
            if(order[1]=="-cpp"){
                std::string op="..\\..\\bin\\MinGW64\\bin\\g++.exe ",spec=" ";
                int pos=order[2].find_last_of('.');
                op=op+order[2]+" -o "+order[2].substr(0,pos);
                for(int i=3;i<length;i++)spec=spec+" "+order[i];
                system(("powershell "+op+spec).c_str());
                system(("powershell .\\"+order[2].substr(0,pos)).c_str());
            }else if(order[1]=="-py"){
                std::string op="..\\..\\bin\\Python312\\python \""+order[2]+"\"";
                system(("powershell "+op).c_str());
            }else if(order[1]=="-rust"){
                std::string op="rustc "+order[2]+"\"";
                system(("powershell "+op).c_str());
            }
        }
        else system(input.c_str());
    }
}