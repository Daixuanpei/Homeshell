#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HomeShell - 简易终端文件管理器

所有文件操作都被限制在 home 目录内。
仅使用 Python 标准库，无第三方依赖。
"""

from __future__ import annotations

import ctypes
import difflib
import os
import shutil
import stat
import subprocess
import sys
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Callable

APP_NAME = "HomeShell"
APP_VERSION = "1.1.0"

SYSTEM_DIR = Path(__file__).resolve().parent
ROOT = SYSTEM_DIR.parent
LAUNCHER = ROOT / "启动终端.bat"
BIN_DIR = ROOT / "bin"
MINGW64_DIR = ROOT / "bin" / "MinGW64" / "bin"
CPP_SUFFIXES = {".cpp", ".cc", ".cxx", ".c++"}
DEBUG = os.environ.get("FILESHELL_DEBUG") == "1"

_ANSI = False


# ---------------------------------------------------------------------------
# 终端与文本工具
# ---------------------------------------------------------------------------

def _supports_ansi() -> bool:
    """检测当前终端是否支持 ANSI 转义序列。"""
    if not sys.stdout.isatty() or os.environ.get("NO_COLOR"):
        return False
    if os.name != "nt":
        return True
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        enable_vt = 0x0004
        if mode.value & enable_vt:
            return True
        return bool(kernel32.SetConsoleMode(handle, mode.value | enable_vt))
    except Exception:
        return False


def configure_console() -> None:
    """尽量把控制台切换为 UTF-8，避免中文乱码。"""
    global _ANSI

    if os.name == "nt":
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleOutputCP(65001)
            kernel32.SetConsoleCP(65001)
        except Exception:
            pass

    for stream in (sys.stdin, sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    _ANSI = _supports_ansi()


def style(text: str, code: str) -> str:
    if not _ANSI:
        return text
    return f"\033[{code}m{text}\033[0m"


def display_width(text: str) -> int:
    width = 0
    for char in text:
        if unicodedata.combining(char):
            continue
        width += 2 if unicodedata.east_asian_width(char) in ("W", "F") else 1
    return width


def pad(text: str, width: int) -> str:
    return text + " " * max(0, width - display_width(text))


def human_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            if unit == "B":
                return f"{int(value)} B"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def format_time(timestamp: float) -> str:
    try:
        return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M")
    except (OSError, OverflowError, ValueError):
        return "?"


def split_command(line: str) -> list[str]:
    """按空格拆分命令，支持引号，并保留 Windows 路径中的反斜杠。"""
    tokens: list[str] = []
    buffer: list[str] = []
    quote: str | None = None
    started = False
    index = 0

    while index < len(line):
        char = line[index]

        if quote:
            if char == quote:
                quote = None
            elif char == "\\" and index + 1 < len(line) and line[index + 1] in (quote, "\\"):
                buffer.append(line[index + 1])
                index += 1
            else:
                buffer.append(char)
        else:
            if char in ("'", '"'):
                quote = char
                started = True
            elif char.isspace():
                if started:
                    tokens.append("".join(buffer))
                    buffer = []
                    started = False
            elif char == "\\" and index + 1 < len(line) and line[index + 1] in ('"', "'", " "):
                buffer.append(line[index + 1])
                index += 1
                started = True
            else:
                buffer.append(char)
                started = True

        index += 1

    if quote:
        raise ValueError("引号没有闭合。")
    if started:
        tokens.append("".join(buffer))

    return tokens


# ---------------------------------------------------------------------------
# 文件管理器
# ---------------------------------------------------------------------------

class ShellError(Exception):
    """可以直接展示给用户的错误。"""


class FileShell:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.main_root = self.root
        self.cwd = self.root
        self.previous_cwd: Path | None = None
        self.running = True
        self.system_label = "HomeShell"

        # 工具链探测结果缓存
        self._gxx: Path | None = None
        self._gxx_ready = False
        self._gcc_root: Path | None = None
        self._gcc_root_ready = False
        self._gcc_layout_cache: dict[str, object] | None = None
        self._python: Path | None = None
        self._python_ready = False
        self._python_source = ""
        self._python_bin_note = ""

        self.commands: dict[str, Callable[[list[str]], None]] = {
            # 浏览
            "ls": self.cmd_ls,
            "cd": self.cmd_cd,
            "pwd": self.cmd_pwd,
            "open": self.cmd_open,
            "tree": self.cmd_tree,
            "edit": self.cmd_edit,
            "编辑": self.cmd_edit,
            "notepad": self.cmd_edit,
            "记事本": self.cmd_edit,
            "nano": self.cmd_edit,
            "vi": self.cmd_edit,
            "vim": self.cmd_edit,
            # 编译与运行
            "build": self.cmd_build,
            "compile": self.cmd_build,
            "编译": self.cmd_build,
            "g++": self.cmd_build,
            "run": self.cmd_run,
            "运行": self.cmd_run,
            "py": self.cmd_py,
            "python": self.cmd_py,
            "python3": self.cmd_py,
            "tools": self.cmd_tools,
            "tool": self.cmd_tools,
            "工具": self.cmd_tools,
            # 系统切换
            "启用rust": self.cmd_enable_rust,
            "enable_rust": self.cmd_enable_rust,
            "子系统rust": self.cmd_enable_rust,
            "启用cpp": self.cmd_enable_cpp,
            "enable_cpp": self.cmd_enable_cpp,
            "子系统cpp": self.cmd_enable_cpp,
            "返回": self.cmd_back,
            "back": self.cmd_back,
            "主系统": self.cmd_back,
            # 创建与编辑
            "mkdir": self.cmd_mkdir,
            "touch": self.cmd_touch,
            "write": self.cmd_write,
            "rename": self.cmd_rename,
            # 删除
            "rm": self.cmd_rm,
            "rmdir": self.cmd_rmdir,
            # 其他
            "start": self.cmd_start,
            "clear": self.cmd_clear,
            "help": self.cmd_help,
            "exit": self.cmd_exit,
            # 常用别名
            "dir": self.cmd_ls,
            "列表": self.cmd_ls,
            "进入": self.cmd_cd,
            "当前目录": self.cmd_pwd,
            "打开": self.cmd_open,
            "cat": self.cmd_open,
            "view": self.cmd_open,
            "type": self.cmd_open,
            "查看": self.cmd_open,
            "md": self.cmd_mkdir,
            "新建文件夹": self.cmd_mkdir,
            "new": self.cmd_touch,
            "新建文件": self.cmd_touch,
            "写入": self.cmd_write,
            "del": self.cmd_rm,
            "delete": self.cmd_rm,
            "删除": self.cmd_rm,
            "rd": self.cmd_rmdir,
            "mv": self.cmd_rename,
            "move": self.cmd_rename,
            "重命名": self.cmd_rename,
            "explorer": self.cmd_start,
            "资源管理器": self.cmd_start,
            "cls": self.cmd_clear,
            "清屏": self.cmd_clear,
            "?": self.cmd_help,
            "帮助": self.cmd_help,
            "quit": self.cmd_exit,
            "q": self.cmd_exit,
            "退出": self.cmd_exit,
        }

    # -- 主循环 ------------------------------------------------------------

    def run(self) -> None:
        self._set_title()
        self._print_banner()
        try:
            self.list_entries(self.cwd)
        except ShellError as exc:
            self.error(str(exc))
        print()

        while self.running:
            try:
                line = input(self._prompt())
            except EOFError:
                print()
                self.ok("再见！")
                break
            except KeyboardInterrupt:
                print()
                self.warn("已取消当前输入。")
                continue

            line = line.lstrip("\ufeff")
            if line.strip():
                self.execute(line)

    def execute(self, line: str) -> None:
        try:
            parts = split_command(line)
        except ValueError as exc:
            self.error(str(exc))
            return

        if not parts:
            return

        name = parts[0].lower()
        handler = self.commands.get(name)
        if handler is None:
            self.error(f"未知命令: {parts[0]}")
            guess = difflib.get_close_matches(name, list(self.commands), n=1, cutoff=0.6)
            if guess:
                print(f"  是不是想输入 {style(guess[0], '33;1')}？")
            print("  输入 help 查看可用命令。")
            return

        try:
            handler(parts[1:])
        except ShellError as exc:
            self.error(str(exc))
        except (OSError, ValueError) as exc:
            self.error(f"操作失败: {exc}")
        except KeyboardInterrupt:
            print()
            self.warn("操作已取消。")
        except Exception as exc:
            if DEBUG:
                raise
            self.error(f"发生未预期的错误: {exc}")

    # -- 输出与提示 --------------------------------------------------------

    def _prompt(self) -> str:
        return style(self.display_path(self.cwd), "36;1") + " > "

    def _print_banner(self) -> None:
        line = "=" * 66
        print(style(line, "36"))
        print(style(f"  {APP_NAME}  ·  简易终端文件管理器  v{APP_VERSION}", "36;1"))
        print(style(line, "36"))
        print(f"根目录  : {self.root}")
        print(f"当前目录: {self.display_path(self.cwd)}")
        print(f"系统    : {self.system_label}")
        print(style("提示: 输入 help 查看命令，exit 退出。", "2"))

    def _set_title(self) -> None:
        if os.name != "nt":
            return
        try:
            ctypes.windll.kernel32.SetConsoleTitleW(
                f"{APP_NAME} - {self.display_path(self.cwd)}"
            )
        except Exception:
            pass

    def ok(self, message: str) -> None:
        print(style("[完成] ", "32;1") + message)

    def warn(self, message: str) -> None:
        print(style("[提示] ", "33;1") + message)

    def error(self, message: str) -> None:
        print(style("错误: ", "31;1") + message)

    def info(self, message: str) -> None:
        print(style(message, "2"))

    # -- 路径与安全 --------------------------------------------------------

    def display_path(self, path: Path) -> str:
        try:
            relative = path.relative_to(self.root)
        except ValueError:
            return str(path)
        if relative == Path("."):
            return "~"
        return "~/" + relative.as_posix()

    def resolve(
        self,
        raw: str,
        *,
        follow_final: bool = False,
        must_exist: bool = False,
    ) -> Path:
        text = raw.strip()
        if not text:
            raise ShellError("路径不能为空。")

        if text in ("~", "/", "\\"):
            candidate = self.root
        elif text.startswith("~/") or text.startswith("~\\"):
            candidate = self.root / text[2:]
        elif text.startswith("/") or text.startswith("\\"):
            candidate = self.root / text[1:]
        else:
            candidate = Path(text)
            if not candidate.is_absolute():
                candidate = self.cwd / candidate

        try:
            candidate = Path(os.path.abspath(str(candidate)))
            if candidate == self.root:
                resolved = self.root
            else:
                parent = candidate.parent.resolve(strict=False)
                resolved = parent / candidate.name

            if follow_final and self.is_link_like(resolved):
                resolved = resolved.resolve(strict=False)
        except (OSError, RuntimeError) as exc:
            raise ShellError(f"无法解析路径: {exc}") from exc

        try:
            resolved.relative_to(self.root)
        except ValueError as exc:
            raise ShellError(f"路径超出 home 范围: {raw}") from exc

        if must_exist and not resolved.exists() and not self.is_link_like(resolved):
            raise ShellError(f"路径不存在: {raw}")

        return resolved

    def ensure_mutable(self, path: Path) -> None:
        if path == self.root:
            raise ShellError("不能修改当前系统的根目录。")
        if path == LAUNCHER:
            raise ShellError("这是启动文件，不能修改。")
        if path == SYSTEM_DIR / "fileshell.py":
            raise ShellError("这是系统核心文件，不能修改。")

    def ensure_safe_creation(self, path: Path) -> None:
        self.ensure_mutable(path)
        if self.is_link_like(path):
            raise ShellError(f"目标路径是链接，不能写入: {self.display_path(path)}")
        try:
            resolved = path.resolve(strict=False)
            resolved.relative_to(self.root)
        except (OSError, ValueError) as exc:
            raise ShellError(f"输出路径超出 home 范围: {self.display_path(path)}") from exc

    def ensure_not_cwd(self, path: Path, action: str = "修改") -> None:
        if path == self.cwd or path in self.cwd.parents:
            raise ShellError(f"不能{action}当前所在目录或其上级目录。")

    @staticmethod
    def is_junction(path: Path) -> bool:
        try:
            checker = getattr(path, "is_junction", None)
            return bool(checker and checker())
        except OSError:
            return False

    @staticmethod
    def is_link_like(path: Path) -> bool:
        try:
            if path.is_symlink():
                return True
            return FileShell.is_junction(path)
        except OSError:
            return False

    def find_junction_inside(self, path: Path) -> Path | None:
        stack = [path]
        while stack:
            current = stack.pop()
            try:
                with os.scandir(current) as iterator:
                    entries = list(iterator)
            except OSError:
                continue

            for entry in entries:
                entry_path = Path(entry.path)
                if self.is_junction(entry_path):
                    return entry_path
                try:
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(entry_path)
                except OSError:
                    continue
        return None

    # -- 编译工具链 --------------------------------------------------------

    @staticmethod
    def _works(path: Path, args: tuple[str, ...] = ("--version",)) -> bool:
        try:
            if not path.is_file() or path.stat().st_size == 0:
                return False
            result = subprocess.run(
                [str(path), *args],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=8,
            )
            return result.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False

    @staticmethod
    def _tool_version(path: Path, args: tuple[str, ...] = ("--version",)) -> str:
        try:
            result = subprocess.run(
                [str(path), *args],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=8,
            )
        except (OSError, subprocess.TimeoutExpired):
            return ""

        raw = result.stdout or result.stderr
        for line in raw.decode("utf-8", errors="replace").splitlines():
            if line.strip():
                return line.strip()
        return ""

    def find_gxx(self) -> Path | None:
        if self._gxx_ready:
            return self._gxx

        mingw_gxx = MINGW64_DIR / ("g++.exe" if os.name == "nt" else "g++")
        bin_gxx = BIN_DIR / ("g++.exe" if os.name == "nt" else "g++")
        path_gxx = shutil.which("g++")
        path_gxx_path = Path(path_gxx) if path_gxx else None

        candidates: list[Path] = []
        if mingw_gxx.is_file():
            candidates.append(mingw_gxx)
        if bin_gxx.is_file() and bin_gxx not in candidates:
            candidates.append(bin_gxx)
        if path_gxx_path is not None and path_gxx_path not in candidates:
            candidates.append(path_gxx_path)

        selected: Path | None = None
        selected_root: Path | None = None

        for candidate in candidates:
            root = self._discover_gcc_root(candidate)
            if root is not None:
                selected = candidate
                selected_root = root
                break

        if selected is None:
            if mingw_gxx.is_file():
                selected = mingw_gxx
            elif bin_gxx.is_file():
                selected = bin_gxx
            elif path_gxx_path is not None:
                selected = path_gxx_path

        self._gxx = selected
        self._gxx_ready = True
        
        if selected_root is not None:
            self._gcc_root = selected_root
            self._gcc_root_ready = True
        elif not self._gcc_root_ready and selected is not None:
            self._gcc_root = self._discover_gcc_root(selected)
            self._gcc_root_ready = True

        return self._gxx

    def _discover_gcc_root(self, gxx: Path | None) -> Path | None:
        if gxx is None:
            return None

        for candidate in (gxx.parent.parent, gxx.parent):
            if self._valid_gcc_root(candidate):
                return candidate.resolve()

        if os.name == "nt":
            try:
                result = subprocess.run(
                    ["fsutil", "hardlink", "list", str(gxx)],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5
                )
                if result.returncode == 0:
                    text = result.stdout.decode("utf-8", errors="replace")
                    for line in text.splitlines():
                        line = line.strip()
                        if not line: continue
                        candidate = Path(line)
                        if not candidate.drive and gxx.drive:
                            candidate = Path(gxx.drive + line)
                        root = candidate.parent.parent
                        if self._valid_gcc_root(root):
                            return root.resolve()
            except Exception:
                pass

        return None

    @staticmethod
    def _valid_gcc_root(root: Path) -> bool:
        try:
            if not root.is_dir():
                return False
            has_cc1 = (root / "bin" / "cc1plus.exe").is_file() or \
                      any((root / "lib").glob("**/cc1plus.exe"))
            has_include = (root / "include").is_dir()
            return has_cc1 and has_include
        except OSError:
            return False

    def find_gcc_root(self) -> Path | None:
        if not self._gcc_root_ready:
            gxx = self.find_gxx()
            if not self._gcc_root_ready:
                self._gcc_root = self._discover_gcc_root(gxx) if gxx else None
                self._gcc_root_ready = True
        return self._gcc_root

    def _discover_gcc_root(self, gxx: Path | None) -> Path | None:
        configured = os.environ.get("HOMESHELL_GCC_ROOT")
        if configured:
            configured_path = Path(configured).expanduser()
            for candidate in (configured_path, configured_path.parent):
                if self._valid_gcc_root(candidate):
                    return candidate.resolve()

        if gxx is None:
            return None

        for candidate in (gxx.parent.parent, gxx.parent):
            if self._valid_gcc_root(candidate):
                return candidate.resolve()

        if os.name == "nt":
            try:
                result = subprocess.run(
                    ["fsutil", "hardlink", "list", str(gxx)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=10,
                )
                if result.returncode == 0:
                    text = result.stdout.decode("utf-8", errors="replace")
                    for line in text.splitlines():
                        line = line.strip()
                        if not line:
                            continue
                        candidate = Path(line)
                        if not candidate.drive and gxx.drive:
                            candidate = Path(gxx.drive + line)
                        root = candidate.parent.parent
                        if self._valid_gcc_root(root):
                            return root.resolve()
            except (OSError, subprocess.TimeoutExpired):
                pass

        candidates: list[Path] = [
            Path("C:/Dev-Cpp/msys2/ucrt64"),
            Path("C:/Program Files/Dev-Cpp/msys2/ucrt64"),
            Path("C:/Program Files (x86)/Dev-Cpp/msys2/ucrt64"),
            Path("C:/msys64/ucrt64"),
            Path("C:/msys64/mingw64"),
            Path("C:/mingw64"),
            Path("C:/MinGW"),
            Path.home() / "Desktop" / "Dev-Cpp" / "msys2" / "ucrt64",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Dev-Cpp" / "msys2" / "ucrt64",
        ]

        if os.name == "nt":
            users_dir = Path("C:/Users")
            try:
                for user_dir in users_dir.iterdir():
                    if not user_dir.is_dir():
                        continue
                    candidates.append(user_dir / "Desktop" / "Dev-Cpp" / "msys2" / "ucrt64")
                    candidates.append(user_dir / "Dev-Cpp" / "msys2" / "ucrt64")
            except OSError:
                pass

        for candidate in candidates:
            if self._valid_gcc_root(candidate):
                return candidate.resolve()

        return None

    def gcc_layout(self) -> dict[str, object] | None:
        if self._gcc_layout_cache is not None:
            return self._gcc_layout_cache

        root = self.find_gcc_root()
        if root is None:
            return None

        cc1_candidates: list[Path] = []
        try:
            cc1_candidates = list((root / "lib" / "gcc").glob("*/*/cc1plus.exe"))
        except OSError:
            pass
        if not cc1_candidates:
            cc1_candidates = [root / "bin" / "cc1plus.exe"]

        cc1_candidates = [path for path in cc1_candidates if path.is_file()]
        if not cc1_candidates:
            return None

        try:
            cc1 = max(cc1_candidates, key=lambda path: path.stat().st_mtime)
        except OSError:
            cc1 = cc1_candidates[0]

        if cc1.parent.name == "bin":
            target = ""
            cxx_roots = sorted((root / "include" / "c++").glob("*"), key=lambda path: path.name)
            version = cxx_roots[-1].name if cxx_roots else ""
        else:
            version = cc1.parent.name
            target = cc1.parent.parent.name

        includes: list[Path] = []
        if version:
            includes.append(root / "include" / "c++" / version)
            if target:
                includes.append(root / "include" / "c++" / version / target)
        includes.append(root / "include")

        target_bin = root / target / "bin" if target else None
        target_lib = root / target / "lib" if target else None

        compiler_dirs = [cc1.parent, root / "bin"]
        if target_bin is not None:
            compiler_dirs.append(target_bin)

        libraries = [root / "lib", cc1.parent]
        if target_lib is not None:
            libraries.append(target_lib)

        layout: dict[str, object] = {
            "root": root,
            "cc1": cc1,
            "compiler_dirs": compiler_dirs,
            "includes": [path for path in includes if path.is_dir()],
            "libraries": [path for path in libraries if path.is_dir()],
            "target_bin": target_bin,
        }
        self._gcc_layout_cache = layout
        return layout

    def compiler_env(self) -> dict[str, str]:
        env = os.environ.copy()
        
        path_parts = [str(MINGW64_DIR), str(BIN_DIR)]
        layout = self.gcc_layout()

        if layout is not None:
            root = layout["root"]
            compiler_dirs = [str(path) for path in layout["compiler_dirs"] if path.is_dir()]
            includes = [str(path) for path in layout["includes"]]
            libraries = [str(path) for path in layout["libraries"]]
            target_bin = layout["target_bin"]

            path_parts = [str(root / "bin")]
            if target_bin is not None:
                path_parts.append(str(target_bin))
            path_parts.append(str(MINGW64_DIR))
            path_parts.append(str(BIN_DIR))

            env["COMPILER_PATH"] = os.pathsep.join(compiler_dirs)
            env["CPLUS_INCLUDE_PATH"] = os.pathsep.join(includes)
            env["C_INCLUDE_PATH"] = os.pathsep.join(includes)
            env["LIBRARY_PATH"] = os.pathsep.join(libraries)

        env["PATH"] = os.pathsep.join(path_parts + [env.get("PATH", "")])
        return env

    def find_python(self) -> Path | None:
        if self._python_ready:
            return self._python

        broken_bin = BIN_DIR / ("python3.exe" if os.name == "nt" else "python3")
        broken_alt = BIN_DIR / "python3"
        for candidate in (broken_bin, broken_alt):
            if not os.path.lexists(str(candidate)):
                continue
            try:
                if candidate.stat().st_size == 0:
                    self._python_bin_note = (
                        f"bin/{candidate.name} 是 0 字节文件，已忽略"
                    )
                elif not self._works(candidate):
                    self._python_bin_note = f"bin/{candidate.name} 无法执行，已忽略"
            except OSError:
                self._python_bin_note = f"bin/{candidate.name} 无法读取，已忽略"
            break

        candidates: list[tuple[Path, str]] = []
        for directory_name in ("Python312", "python312"):
            directory = BIN_DIR / directory_name
            for executable_name in ("python.exe", "python3.exe"):
                candidates.append(
                    (directory / executable_name, f"bin/{directory.name}/{executable_name}")
                )

        bin_names = ["python3.exe", "python.exe"] if os.name == "nt" else ["python3", "python"]
        for name in bin_names:
            candidates.append((BIN_DIR / name, f"bin/{name}"))

        for name in ("python3", "python"):
            found = shutil.which(name)
            if found:
                candidates.append((Path(found), f"PATH 中的 {name}"))

        candidates.append((Path(sys.executable), "内置 Python 运行时"))

        seen: set[Path] = set()
        for candidate, source in candidates:
            try:
                candidate = candidate.resolve()
            except OSError:
                continue
            if candidate in seen:
                continue
            seen.add(candidate)

            if candidate.is_file() and candidate.stat().st_size > 0 and self._works(candidate):
                self._python = candidate
                self._python_source = source
                self._python_ready = True
                return self._python

        self._python = None
        self._python_source = ""
        self._python_ready = True
        return None

    @staticmethod
    def python_env() -> dict[str, str]:
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        env.pop("PYTHONDONTWRITEBYTECODE", None)
        env.pop("PYTHONPYCACHEPREFIX", None)
        return env

    def program_env(self) -> dict[str, str]:
        env = self.python_env()
        layout = self.gcc_layout()
        if layout is not None:
            root = layout["root"]
            env["PATH"] = os.pathsep.join(
                [str(root / "bin"), str(BIN_DIR), env.get("PATH", "")]
            )
        return env

    @staticmethod
    def is_real_dir(path: Path) -> bool:
        try:
            return path.is_dir() and not FileShell.is_link_like(path)
        except OSError:
            return False

    @staticmethod
    def unlink(path: Path) -> None:
        try:
            path.unlink()
        except PermissionError:
            os.chmod(path, stat.S_IWRITE)
            path.unlink()

    # -- 目录展示 ----------------------------------------------------------

    @staticmethod
    def entry_type(entry: Path) -> tuple[str, bool]:
        if FileShell.is_link_like(entry):
            return "[链接]", False
        try:
            if entry.is_dir():
                return "[目录]", True
            if entry.is_file():
                return "[文件]", False
        except OSError:
            pass
        return "[其他]", False

    @staticmethod
    def entry_name(entry: Path) -> str:
        if FileShell.is_link_like(entry):
            return entry.name + "@"
        try:
            if entry.is_dir():
                return entry.name + "/"
        except OSError:
            pass
        return entry.name

    def list_entries(self, path: Path, show_hidden: bool = False) -> None:
        if not path.exists():
            raise ShellError(f"目录不存在: {self.display_path(path)}")
        if not path.is_dir():
            raise ShellError(f"不是文件夹: {self.display_path(path)}")

        try:
            entries = [
                entry
                for entry in path.iterdir()
                if show_hidden or not entry.name.startswith(".")
            ]
        except OSError as exc:
            raise ShellError(f"无法读取目录: {exc}") from exc

        entries.sort(key=lambda entry: (0 if self.is_real_dir(entry) else 1, entry.name.casefold()))

        print(style(f"目录: {self.display_path(path)}", "36;1"))
        if not entries:
            self.info("  (空目录)")
            return

        name_width = max(12, *(display_width(self.entry_name(entry)) for entry in entries))
        print(
            "  "
            + pad("类型", 6)
            + " "
            + pad("名称", name_width)
            + " "
            + "大小".rjust(9)
            + "  修改时间"
        )
        print(style("  " + "-" * (name_width + 37), "2"))

        for entry in entries:
            label, is_dir = self.entry_type(entry)
            name = self.entry_name(entry)
            gap = " " * max(0, name_width - display_width(name))
            rendered_name = (style(name, "34;1") if is_dir else name) + gap

            try:
                stat_result = entry.lstat()
                modified = format_time(stat_result.st_mtime)
                size = "-" if is_dir or self.is_link_like(entry) else human_size(stat_result.st_size)
            except OSError:
                modified = "?"
                size = "?"

            print(f"  {pad(label, 6)} {rendered_name} {size:>9}  {modified}")

        self.info(f"  共 {len(entries)} 项")

    # -- 浏览命令 ----------------------------------------------------------

    def cmd_ls(self, args: list[str]) -> None:
        flags, rest = self.parse_flags(args, {"a"})
        if len(rest) > 1:
            raise ShellError("用法: ls [-a] [目录]")

        path = self.resolve(rest[0], follow_final=True, must_exist=True) if rest else self.cwd

        if path.is_file():
            try:
                size = human_size(path.stat().st_size)
            except OSError:
                size = "?"
            print(f"{self.display_path(path)}  ({size})")
            return

        if not path.is_dir():
            raise ShellError(f"无法列出: {self.display_path(path)}")

        self.list_entries(path, show_hidden="a" in flags)
        
    def change_dir(self, target: Path) -> None:
        if not target.exists():
            raise ShellError(f"目录不存在: {self.display_path(target)}")
        if not target.is_dir():
            raise ShellError(f"不是文件夹: {self.display_path(target)}")

        if target != self.cwd:
            self.previous_cwd = self.cwd
        self.cwd = target
        self._set_title()
        self.ok(f"当前目录: {self.display_path(self.cwd)}")

    def cmd_cd(self, args: list[str]) -> None:
        if len(args) > 1:
            raise ShellError("用法: cd [目录]")

        if not args:
            target = self.root
        elif args[0] == "-":
            if self.previous_cwd is None:
                raise ShellError("还没有上一个目录。")
            target = self.previous_cwd
        else:
            target = self.resolve(args[0], follow_final=True, must_exist=True)

        self.change_dir(target)

    def cmd_pwd(self, args: list[str]) -> None:
        if args:
            raise ShellError("用法: pwd")
        print(f"当前目录: {self.display_path(self.cwd)}")
        print(f"完整路径: {self.cwd}")
    
    def cmd_open(self, args: list[str]) -> None:
        if not args:
            raise ShellError("用法: open <目录|文件>")

        target = self.resolve(" ".join(args), follow_final=True, must_exist=True)
        if not target.exists():
            raise ShellError(f"路径不存在或链接已失效: {self.display_path(target)}")

        if target.is_dir():
            self.change_dir(target)
            self.list_entries(self.cwd)
        elif target.is_file():
            self.preview_file(target)
        else:
            raise ShellError(f"无法打开: {self.display_path(target)}")

    def cmd_edit(self, args: list[str]) -> None:
        import tkinter as tk
        from tkinter import messagebox
        from tkinter import scrolledtext
        
        if len(args) != 1:
            raise ShellError("用法: edit <文件>")

        target = self.resolve(args[0], follow_final=True)
        if target.is_dir():
            raise ShellError(f"不能编辑文件夹: {self.display_path(target)}")
        if not target.parent.is_dir():
            raise ShellError(f"上级文件夹不存在: {self.display_path(target.parent)}")
        self.ensure_mutable(target)

        content = ""
        if target.exists():
            try:
                content = target.read_text(encoding="utf-8")
            except Exception as e:
                raise ShellError(f"读取文件失败: {e}")

        root = tk.Tk()
        root.title(f"HomeShell 编辑器 - {target.name}")
        root.geometry("800x600")
        
        bg_color = "#1e1e1e"
        fg_color = "#d4d4d4"
        root.configure(bg=bg_color)
        
        text_area = scrolledtext.ScrolledText(
            root, wrap=tk.NONE, undo=True,
            bg=bg_color, fg=fg_color, 
            insertbackground="white",
            font=("Consolas", 14)
        )
        text_area.pack(fill=tk.BOTH, expand=True)
        text_area.insert(tk.END, content)
        text_area.focus_set()

        status_var = tk.StringVar()
        status_var.set("就绪 | Ctrl+S 保存 | 直接关闭窗口退出")
        status_bar = tk.Label(root, textvariable=status_var, bg="#2d2d2d", fg="#858585", anchor="w")
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        def handle_return(event):
            current_index = text_area.index(tk.INSERT)
            line_start = text_area.index(f"{current_index} linestart")
            line_text = text_area.get(line_start, current_index)
            
            indent = ""
            for char in line_text:
                if char in (' ', '\t'):
                    indent += char
                else:
                    break
            
            stripped_text = line_text.strip()
            extra_indent = ""
            if stripped_text.endswith('{') or stripped_text.endswith(':'):
                extra_indent = "    "
                
            char_after = text_area.get(current_index, f"{current_index}+1c")
            if char_after in ('}', ')'):
                text_area.insert(tk.INSERT, f"\n{indent}{extra_indent}\n{indent}")
                text_area.mark_set(tk.INSERT, f"{current_index} + 1 line + {len(indent) + len(extra_indent)} chars")
            else:
                text_area.insert(tk.INSERT, f"\n{indent}{extra_indent}")
            
            return "break"

        text_area.bind("<Return>", handle_return)

        def save_file(event=None):
            try:
                new_content = text_area.get("1.0", tk.END)
                if new_content.endswith('\n'):
                    new_content = new_content[:-1]
                
                target.write_text(new_content, encoding="utf-8")
                status_var.set(f"✅ 已保存于 {datetime.now().strftime('%H:%M:%S')}")
            except Exception as e:
                messagebox.showerror("保存失败", str(e))
            return "break"

        text_area.bind("<Control-s>", save_file)
        text_area.bind("<Command-s>", save_file)

        def on_close():
            root.destroy()

        root.protocol("WM_DELETE_WINDOW", on_close)
        root.attributes('-topmost', True)
        root.update()
        root.attributes('-topmost', False)

        root.mainloop()
        self.ok(f"已关闭编辑器: {self.display_path(target)}")
    
    def preview_file(self, path: Path) -> None:
        try:
            stat_result = path.stat()
        except OSError as exc:
            raise ShellError(f"无法读取文件: {exc}") from exc

        print(style(f"文件: {self.display_path(path)}  ({human_size(stat_result.st_size)})", "36;1"))
        print(style("-" * 66, "2"))

        if stat_result.st_size == 0:
            self.info("  (空文件)")
            return

        limit = 64 * 1024
        try:
            with path.open("rb") as handle:
                raw = handle.read(limit)
        except OSError as exc:
            raise ShellError(f"无法读取文件: {exc}") from exc

        if b"\x00" in raw[:8192]:
            print("  这是二进制文件，无法在终端中预览。")
            print(f"  可输入: start \"{path.name}\" 用系统默认程序打开。")
            return

        text = None
        for encoding in ("utf-8-sig", "gb18030"):
            try:
                text = raw.decode(encoding)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            text = raw.decode("utf-8", errors="replace")

        text = text.replace("\r\n", "\n").replace("\r", "\n")
        text = "".join(
            char if char in "\n\t" or (ord(char) >= 32 and ord(char) != 127) else "·"
            for char in text
        )

        lines = text.split("\n")
        if lines and lines[-1] == "":
            lines.pop()

        max_lines = 200
        shown = lines[:max_lines]
        for line in shown:
            print("  " + line)

        truncated = stat_result.st_size > limit or len(lines) > max_lines
        if truncated:
            self.info("  (内容已截断，仅显示前 200 行 / 64 KB)")
        else:
            self.info(f"  (共 {len(lines)} 行)")

    def cmd_tree(self, args: list[str]) -> None:
        if len(args) > 1:
            raise ShellError("用法: tree [深度]")

        depth = 3
        if args:
            try:
                depth = int(args[0])
            except ValueError as exc:
                raise ShellError("深度必须是整数。") from exc
            if not 1 <= depth <= 8:
                raise ShellError("深度范围是 1 到 8。")

        print(style(f"{self.display_path(self.cwd)}/", "36;1"))
        counter = [0]
        truncated = [False]
        self._print_tree(self.cwd, "", depth, 1, counter, truncated)
        if truncated[0]:
            self.info("... 条目过多，已省略部分内容。")

    def _print_tree(
        self,
        path: Path,
        prefix: str,
        max_depth: int,
        level: int,
        counter: list[int],
        truncated: list[bool],
    ) -> None:
        try:
            entries = [entry for entry in path.iterdir() if not entry.name.startswith(".")]
        except OSError:
            print(prefix + "└── [无法访问]")
            return

        entries.sort(key=lambda entry: (0 if self.is_real_dir(entry) else 1, entry.name.casefold()))

        for index, entry in enumerate(entries):
            if counter[0] >= 300:
                truncated[0] = True
                return
            counter[0] += 1

            last = index == len(entries) - 1
            connector = "└── " if last else "├── "
            is_link = self.is_link_like(entry)
            is_dir = self.is_real_dir(entry)
            suffix = "/" if is_dir else ("@" if is_link else "")
            print(prefix + connector + entry.name + suffix)

            if is_dir and level < max_depth:
                self._print_tree(
                    entry,
                    prefix + ("    " if last else "│   "),
                    max_depth,
                    level + 1,
                    counter,
                    truncated,
                )

    # -- 编译与运行 --------------------------------------------------------

    @staticmethod
    def _print_process_output(stdout: str, stderr: str) -> None:
        if stdout.strip():
            print(stdout.rstrip())
        if stderr.strip():
            print(stderr.rstrip())

    def _run_capture(
        self,
        command: list[str],
        cwd: Path,
        env: dict[str, str],
    ) -> subprocess.CompletedProcess[str]:
        try:
            return subprocess.run(
                command,
                cwd=str(cwd),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
        except OSError as exc:
            raise ShellError(f"无法启动编译工具: {exc}") from exc

    def cmd_build(self, args: list[str]) -> None:
        if len(args) != 1:
            raise ShellError("用法: build <文件.cpp|文件.py>")

        source = self.resolve(args[0], follow_final=True, must_exist=True)
        if not source.is_file():
            raise ShellError(f"不是文件: {self.display_path(source)}")

        suffix = source.suffix.lower()
        if suffix in CPP_SUFFIXES:
            self.build_cpp(source)
        elif suffix == ".py":
            self.build_python(source)
        else:
            raise ShellError("只支持 C++ 源文件（.cpp/.cc/.cxx/.c++）和 Python 文件（.py）。")

    def build_cpp(self, source: Path) -> Path:
        output = source.with_suffix(".exe")
        self.ensure_safe_creation(output)
        if output.exists() and output.is_dir():
            raise ShellError(f"输出位置被文件夹占用: {self.display_path(output)}")

        gxx = self.find_gxx()
        if gxx is None:
            raise ShellError(
                "未找到可用的 g++ 编译器。\n"
                "请确保：\n"
                "1. 已将完整的 MinGW64 工具链（含 bin/include/lib）放在 home/bin/MinGW64/ 目录下。\n"
                "2. 或者将工具链放在 home/bin/ 目录中。\n"
                "3. 或者工具链已正确配置在系统的环境变量 PATH 中。"
            )

        print(
            style(
                f"正在编译 C++: {self.display_path(source)}  ->  {self.display_path(output)}",
                "36;1",
            )
        )
        command = [
            str(gxx),
            "-std=c++17",
            "-O2",
            "-finput-charset=UTF-8",
        ]
        if os.name == "nt":
            command.append("-static")
        command.extend(["-o", output.name, source.name])

        result = self._run_capture(command, source.parent, self.compiler_env())
        self._print_process_output(result.stdout, result.stderr)
        if result.returncode != 0:
            raise ShellError(f"C++ 编译失败（退出码 {result.returncode}）。")

        if not output.is_file():
            raise ShellError("编译器没有生成可执行文件。")

        try:
            size = output.stat().st_size
        except OSError:
            size = 0
        self.ok(f"C++ 编译完成: {self.display_path(output)}  ({human_size(size)})")
        return output

    def build_python(self, source: Path) -> Path | None:
        python = self.find_python()
        if python is None:
            raise ShellError(
                "未找到可用的 Python。请确认 home/bin/Python312/python.exe 存在，"
                "或把 Python 加入 PATH。"
            )

        print(style(f"正在编译 Python: {self.display_path(source)}", "36;1"))
        self.ensure_safe_creation(source.parent / "__pycache__")
        command = [str(python), "-m", "py_compile", source.name]
        result = self._run_capture(command, source.parent, self.python_env())
        self._print_process_output(result.stdout, result.stderr)
        if result.returncode != 0:
            raise ShellError(f"Python 编译失败（退出码 {result.returncode}）。")

        pycache = source.parent / "__pycache__"
        compiled: Path | None = None
        if pycache.is_dir():
            candidates = [
                path
                for path in pycache.glob("*.pyc")
                if path.name.startswith(source.stem + ".")
            ]
            if candidates:
                compiled = max(candidates, key=lambda path: path.stat().st_mtime)

        if compiled is not None:
            self.ok(f"Python 编译完成: {self.display_path(compiled)}")
        else:
            self.ok("Python 编译完成（已生成 __pycache__ 字节码）。")
        return compiled

    def cmd_run(self, args: list[str]) -> None:
        if not args:
            raise ShellError("用法: run <文件.cpp|文件.py|文件.exe> [参数...]")

        source = self.resolve(args[0], follow_final=True, must_exist=True)
        if not source.is_file():
            raise ShellError(f"不是文件: {self.display_path(source)}")

        suffix = source.suffix.lower()
        run_args = args[1:]
        if suffix in CPP_SUFFIXES:
            executable = self.build_cpp(source)
            self.run_executable(executable, run_args)
        elif suffix == ".py":
            self.run_python(source, run_args)
        elif suffix == ".exe":
            self.run_executable(source, run_args)
        else:
            raise ShellError("只能运行 C++ 源文件、Python 文件或 .exe 文件。")

    def run_executable(self, executable: Path, arguments: list[str]) -> None:
        if not executable.exists():
            raise ShellError(f"可执行文件不存在: {self.display_path(executable)}")
        if executable.is_dir():
            raise ShellError(f"不是文件: {self.display_path(executable)}")

        print(style(f"运行: {self.display_path(executable)}", "36;1"))
        sys.stdout.flush()
        try:
            result = subprocess.run(
                [str(executable), *arguments],
                cwd=str(self.cwd),
                env=self.program_env(),
            )
        except OSError as exc:
            raise ShellError(f"无法运行程序: {exc}") from exc

        if result.returncode == 0:
            self.ok("程序运行结束（退出码 0）。")
        else:
            self.warn(f"程序运行结束（退出码 {result.returncode}）。")

    def run_python(self, script: Path, arguments: list[str]) -> None:
        python = self.find_python()
        if python is None:
            raise ShellError(
                "未找到可用的 Python。请确认 home/bin/Python312/python.exe 存在，"
                "或把 Python 加入 PATH。"
            )

        print(
            style(
                f"运行 Python: {self.display_path(script)}",
                "36;1",
            )
        )
        sys.stdout.flush()
        try:
            result = subprocess.run(
                [str(python), str(script), *arguments],
                cwd=str(self.cwd),
                env=self.python_env(),
            )
        except OSError as exc:
            raise ShellError(f"无法运行 Python: {exc}") from exc

        if result.returncode == 0:
            self.ok("Python 程序运行结束（退出码 0）。")
        else:
            self.warn(f"Python 程序运行结束（退出码 {result.returncode}）。")

    def cmd_py(self, args: list[str]) -> None:
        if not args:
            raise ShellError("用法: py <文件.py> [参数...]")

        script = self.resolve(args[0], follow_final=True, must_exist=True)
        if not script.is_file():
            raise ShellError(f"不是文件: {self.display_path(script)}")
        if script.suffix.lower() != ".py":
            raise ShellError("py 命令只接受 .py 文件。")
        self.run_python(script, args[1:])

    def cmd_tools(self, args: list[str]) -> None:
        if args:
            raise ShellError("用法: tools")

        print(style("HomeShell 工具链", "36;1"))
        print(f"  bin 目录 : {BIN_DIR}")

        gxx = self.find_gxx()
        if gxx is not None:
            print(f"  g++      : {gxx}")
            version = self._tool_version(gxx)
            if version:
                print(f"              {version}")
            root = self.find_gcc_root()
            if root is not None:
                print(f"  MinGW    : {root}")
            else:
                print("  MinGW    : 未找到 cc1plus，C++ 编译可能失败")
        else:
            print("  g++      : 未找到")

        python = self.find_python()
        if python is not None:
            print(f"  Python   : {python}")
            version = self._tool_version(python)
            if version:
                print(f"              {version}")
            print(f"  来源     : {self._python_source}")
        else:
            print("  Python   : 未找到")

        for name in ("python3.exe", "python3"):
            bin_python = BIN_DIR / name
            if not os.path.lexists(str(bin_python)):
                continue
            try:
                size = bin_python.stat().st_size
            except OSError:
                size = 0

            is_selected = False
            if python is not None:
                try:
                    is_selected = python.resolve() == bin_python.resolve()
                except OSError:
                    is_selected = False

            if is_selected:
                status = "可用，当前正在使用"
            elif size == 0:
                status = "已忽略"
            else:
                status = "不可用"
            print(f"  bin Python: {bin_python.name}（{size} 字节，{status}）")

        if self._python_bin_note:
            if python is not None:
                self.warn(f"{self._python_bin_note}；当前使用上方 Python")
            else:
                self.warn(f"{self._python_bin_note}；也没有找到其他 Python")

    # -- 系统切换 ----------------------------------------------------------

    def find_subsystem(self) -> tuple[Path | None, Path | None]:
        bases: list[Path] = []
        configured = os.environ.get("HOMESHELL_SUBSYSTEM_DIR")
        if configured:
            bases.append(Path(configured).expanduser())
        bases.extend(
            [
                SYSTEM_DIR / "children_home",
                ROOT / "children_home",
            ]
        )

        for base in bases:
            if not base.is_dir():
                continue

            sub_home = base / "home"
            root = sub_home if sub_home.is_dir() else base

            candidates = [
                root / "mini_fs" / "src" / "main.exe",
                base / "mini_fs" / "src" / "main.exe",
                root / "mini_fs" / "main.exe",
                root / "main.exe",
                base / "main.exe",
            ]
            for candidate in candidates:
                if candidate.is_file():
                    return root.resolve(), candidate.resolve()

            try:
                found = sorted(
                    base.rglob("main.exe"),
                    key=lambda path: (len(path.parts), str(path).casefold()),
                )
            except OSError:
                found = []
            if found:
                return root.resolve(), found[0].resolve()

            return root.resolve(), None

        return None, None

    def switch_root(self, new_root: Path, label: str) -> None:
        new_root = new_root.resolve()
        if not new_root.is_dir():
            raise ShellError(f"系统根目录不存在: {new_root}")

        self.previous_cwd = self.cwd
        self.root = new_root
        self.cwd = new_root
        self.system_label = label
        self._set_title()
        self._print_banner()
        self.list_entries(self.cwd)

    def cmd_enable_rust(self, args: list[str]) -> None:
        if self.root != self.main_root:
            self.warn("当前已经处于子系统。输入 返回 可回到主系统。")
            return

        root, main_exe = self.find_subsystem()
        if root is None:
            raise ShellError(
                "未找到子系统目录。预期位置: "
                f"{SYSTEM_DIR / 'children_home'}"
            )

        if main_exe is not None:
            print(style(f"正在启用子系统: {root}", "36;1"))
            print(style(f"主程序: {main_exe}", "2"))
            sys.stdout.flush()

            env = os.environ.copy()
            env["HOMESHELL_SUBSYSTEM"] = "1"
            env["HOMESHELL_SUBSYSTEM_ROOT"] = str(root)
            env["HOMESHELL_SUBSYSTEM_MAIN"] = str(main_exe)
            try:
                result = subprocess.run(
                    [str(main_exe), *args],
                    cwd=str(root),
                    env=env,
                )
            except OSError as exc:
                raise ShellError(f"无法启动子系统主程序: {exc}") from exc

            if result.returncode == 0:
                self.ok("子系统已退出，返回 HomeShell。")
            else:
                self.warn(f"子系统已退出（退出码 {result.returncode}），返回 HomeShell。")
            return

        self.warn("子系统没有 main.exe，改为切换当前文件系统根目录。")
        self.switch_root(root, "子系统")
    
    def cmd_enable_cpp(self, args: list[str]) -> None:
        if self.root != self.main_root:
            self.warn("当前已经处于子系统。输入 返回 可回到主系统。")
            return

        root = SYSTEM_DIR / "children_home_by_cpp"
        main_exe = root / "main.exe"

        if not root.is_dir() or not main_exe.is_file():
            raise ShellError(f"未找到 C++ 子系统主程序: {main_exe}")

        print(style(f"正在启用 C++ 子系统: {root}", "36;1"))
        print(style(f"主程序: {main_exe}", "2"))
        sys.stdout.flush()

        env = os.environ.copy()
        env["HOMESHELL_SUBSYSTEM"] = "1"
        env["HOMESHELL_SUBSYSTEM_ROOT"] = str(root)
        env["HOMESHELL_SUBSYSTEM_MAIN"] = str(main_exe)
        
        try:
            result = subprocess.run(
                [str(main_exe), *args],
                cwd=str(root),
                env=env,
            )
        except OSError as exc:
            raise ShellError(f"无法启动子系统主程序: {exc}") from exc

        if result.returncode == 0:
            self.ok("C++ 子系统已退出，返回 HomeShell。")
        else:
            self.warn(f"C++ 子系统已退出（退出码 {result.returncode}），返回 HomeShell。")

    def cmd_back(self, args: list[str]) -> None:
        if args:
            raise ShellError("用法: 返回")
        if self.root == self.main_root:
            self.warn("当前已经是主系统。")
            return
        self.switch_root(self.main_root, "HomeShell")

    # -- 创建与编辑 --------------------------------------------------------

    def cmd_mkdir(self, args: list[str]) -> None:
        if not args:
            raise ShellError("用法: mkdir <目录...>")

        for raw in args:
            try:
                path = self.resolve(raw)
                self.ensure_mutable(path)
                if self.is_link_like(path) or path.exists():
                    self.error(f"已存在: {self.display_path(path)}")
                    continue
                path.mkdir(parents=True, exist_ok=False)
                self.ok(f"已创建文件夹: {self.display_path(path)}/")
            except ShellError as exc:
                self.error(str(exc))
            except OSError as exc:
                self.error(f"创建失败 {raw}: {exc}")

    def cmd_touch(self, args: list[str]) -> None:
        if not args:
            raise ShellError("用法: touch <文件...>")

        for raw in args:
            try:
                path = self.resolve(raw)
                self.ensure_mutable(path)
                if self.is_link_like(path):
                    raise ShellError(f"不能通过符号链接创建文件: {self.display_path(path)}")
                if path.exists() and path.is_dir():
                    raise ShellError(f"同名的文件夹已存在: {self.display_path(path)}")

                existed = path.exists()
                if not existed and not path.parent.is_dir():
                    raise ShellError(f"上级文件夹不存在: {self.display_path(path.parent)}")

                path.touch(exist_ok=True)
                if existed:
                    self.ok(f"已更新时间: {self.display_path(path)}")
                else:
                    self.ok(f"已创建文件: {self.display_path(path)}")
            except ShellError as exc:
                self.error(str(exc))
            except OSError as exc:
                self.error(f"创建失败 {raw}: {exc}")

    def cmd_write(self, args: list[str]) -> None:
        if len(args) < 2:
            raise ShellError('用法: write <文件> <内容...>（内容含空格时请加引号）')

        path = self.resolve(args[0])
        self.ensure_mutable(path)
        if self.is_link_like(path):
            raise ShellError("不能通过符号链接写入文件。")
        if path.exists() and path.is_dir():
            raise ShellError(f"同名的文件夹已存在: {self.display_path(path)}")
        if not path.parent.is_dir():
            raise ShellError(f"上级文件夹不存在: {self.display_path(path.parent)}")

        content = " ".join(args[1:])
        path.write_text(content, encoding="utf-8")
        self.ok(f"已写入 {len(content.encode('utf-8'))} 字节: {self.display_path(path)}")

    def cmd_rename(self, args: list[str]) -> None:
        if len(args) != 2:
            raise ShellError("用法: rename <旧名称> <新名称>")

        source = self.resolve(args[0], follow_final=False, must_exist=True)
        target = self.resolve(args[1], follow_final=False)

        self.ensure_mutable(source)
        self.ensure_mutable(target)
        self.ensure_not_cwd(source, "重命名")

        if source == target:
            raise ShellError("新旧路径相同。")
        if target.exists() or self.is_link_like(target):
            raise ShellError(f"目标已存在: {self.display_path(target)}")

        source.rename(target)
        self.ok(f"已重命名: {self.display_path(source)}  ->  {self.display_path(target)}")

    # -- 删除 --------------------------------------------------------------

    def cmd_rm(self, args: list[str]) -> None:
        flags, targets = self.parse_flags(args, {"r", "f", "i"})
        
        # 【修复点】：如果没有参数，或者参数全是纯空格，触发全删逻辑
        if not targets:
            targets = [" "]

        recursive = "r" in flags
        force = "f" in flags
        interactive = "i" in flags

        if force:
            interactive = False

        for raw in targets:
            # 1. 检查是否是纯空格（或者输入了不存在的文件）
            is_empty_space = raw.strip() == ""
            path = None
            
            if not is_empty_space:
                try:
                    path = self.resolve(raw, follow_final=False)
                except ShellError:
                    path = None 
            
            # 2. 触发条件：输入为空格 或 文件/目录不存在
            if is_empty_space or (path is not None and not path.exists() and not self.is_link_like(path)):
                if not force:
                    self.warn(f"找不到 '{raw}'，系统自动转移为 'rm *' 命令。")
                    if not self.confirm(f"警告: 即将递归删除当前目录 [{self.display_path(self.cwd)}] 下的所有内容，是否继续？"):
                        self.warn("已取消危险操作。")
                        continue
                
                # 执行 rm *
                current_entries = list(self.cwd.iterdir())
                for entry in current_entries:
                    # Linux 下 * 不匹配隐藏文件
                    if entry.name.startswith("."):
                        continue
                    try:
                        # 遇到系统核心文件且是 force 模式，直接跳过
                        if entry == LAUNCHER or entry == SYSTEM_DIR:
                            if force: continue
                            
                        self._do_rm_single(entry, recursive, force, interactive)
                    except Exception as e:
                        self.error(f"删除 {entry.name} 失败: {e}")
                continue # 处理完转移逻辑后，跳过本次循环

            # 3. 以下是正常的单文件/单目录删除流程
            try:
                if path is None:
                    raise ShellError(f"路径无法解析: {raw}")
                    
                self.ensure_mutable(path)
                self.ensure_not_cwd(path, "删除")

                is_dir = path.is_dir() and not self.is_link_like(path)
                if is_dir and not recursive:
                    raise ShellError(f"无法删除 '{raw}': 是一个目录")

                if is_dir and not force:
                    junction = self.find_junction_inside(path)
                    if junction is not None:
                        raise ShellError(f"包含目录联接(junction)，请先处理: {self.display_path(junction)}")

                display = self.display_path(path)
                if path == self.root or path == SYSTEM_DIR or path == LAUNCHER:
                    if force:
                        continue
                    else:
                        self.error(f"安全拦截: 拒绝删除核心系统目录或文件 -> {display}")
                        continue

                self._do_rm_single(path, recursive, force, interactive)

            except ShellError as exc:
                self.error(str(exc))
            except OSError as exc:
                self.error(f"删除失败 {raw}: {exc}")

    def _do_rm_single(self, path: Path, recursive: bool, force: bool, interactive: bool):
        """辅助方法：执行单个路径的删除"""
        display = self.display_path(path)
        is_dir = path.is_dir() and not self.is_link_like(path)
        
        if interactive:
            action = "递归删除文件夹" if is_dir else "删除文件"
            if not self.confirm(f"rm: 是否{action} “{display}”？"):
                self.warn(f"已取消: {display}")
                return

        if is_dir:
            if force:
                shutil.rmtree(path, onerror=self._remove_readonly)
            else:
                shutil.rmtree(path)
        elif self.is_junction(path):
            path.rmdir()
        else:
            if force:
                try:
                    self.unlink(path)
                except OSError:
                    pass
            else:
                self.unlink(path)

    def cmd_rmdir(self, args: list[str]) -> None:
        flags, targets = self.parse_flags(args, {"p", "v", "f"})
        if not targets:
            raise ShellError("用法: rmdir [-pv] <空目录...>")

        recursive_parents = "p" in flags
        verbose = "v" in flags
        force = "f" in flags

        for raw in targets:
            try:
                path = self.resolve(raw, follow_final=False, must_exist=True)
                self.ensure_mutable(path)
                self.ensure_not_cwd(path, "删除")

                if self.is_link_like(path):
                    raise ShellError(f"failed to remove '{raw}': Not a directory")
                
                if not path.is_dir():
                    raise ShellError(f"failed to remove '{raw}': Not a directory")

                def check_and_remove_dir(p: Path):
                    if any(p.iterdir()):
                        raise ShellError(f"failed to remove '{self.display_path(p)}/': Directory not empty")
                    
                    p.rmdir()
                    if verbose:
                        print(f"rmdir: removing directory, '{self.display_path(p)}/'")

                check_and_remove_dir(path)

                if recursive_parents:
                    parent = path.parent
                    while parent != self.root and parent != self.cwd and self.root in parent.parents:
                        try:
                            check_and_remove_dir(parent)
                            parent = parent.parent
                        except ShellError:
                            break

            except ShellError as exc:
                if force:
                    continue
                self.error(str(exc))
            except OSError as exc:
                if force:
                    continue
                self.error(f"删除失败 {raw}: {exc}")

    @staticmethod
    def _remove_readonly(function: Callable, path: str, exc_info: tuple) -> None:
        try:
            os.chmod(path, stat.S_IWRITE)
            function(path)
        except OSError:
            raise

    def confirm(self, question: str) -> bool:
        try:
            answer = input(question + " [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return False
        return answer in ("y", "yes", "是", "确认")

    # -- 其他命令 ----------------------------------------------------------

    def cmd_start(self, args: list[str]) -> None:
        if len(args) > 1:
            raise ShellError("用法: start [路径]")

        target = self.resolve(" ".join(args), follow_final=True) if args else self.cwd
        if not target.exists():
            raise ShellError(f"路径不存在: {self.display_path(target)}")

        try:
            if os.name == "nt":
                os.startfile(str(target))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(target)])
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except OSError as exc:
            raise ShellError(f"无法调用系统程序: {exc}") from exc

        self.ok(f"已请求系统打开: {self.display_path(target)}")

    def cmd_clear(self, args: list[str]) -> None:
        if args:
            raise ShellError("用法: clear")
        if _ANSI:
            print("\033[2J\033[H", end="")
        else:
            os.system("cls" if os.name == "nt" else "clear")
        print(style(f"当前目录: {self.display_path(self.cwd)}", "36;1"))

    def cmd_help(self, args: list[str]) -> None:
        if args:
            raise ShellError("用法: help")

        print(style(f"{APP_NAME} 命令帮助", "36;1"))
        print()
        print(style("浏览", "33;1"))
        print("  ls [-a] [目录]          列出目录内容（-a 显示隐藏项）")
        print("  cd [目录]               进入目录；cd ~ 回根目录；cd - 返回")
        print("  pwd                     显示当前目录")
        print("  open <目录|文件>        打开目录 / 预览文本文件")
        print("  tree [深度]             显示目录树（默认 3 层）")
        print()
        print(style("编译与运行", "33;1"))
        print("  build <文件>            编译 C++ 为 exe / 编译 Python 为 pyc")
        print("  run <文件> [参数...]    编译并运行 C++、运行 Python 或 exe")
        print("  py <文件.py> [参数...]  直接用 Python 运行脚本")
        print("  tools                   查看 g++ / Python 工具链")
        print()
        print(style("创建与编辑", "33;1"))
        print("  mkdir <目录...>         新建文件夹（可自动创建多级）")
        print("  touch <文件...>         新建空文件 / 更新时间")
        print("  write <文件> <内容...>  新建或覆盖文本文件")
        print("  rename <旧名> <新名>    重命名文件或文件夹")
        print()
        print(style("删除", "33;1"))
        print("  rm [-r] [-f] [-i] <路径...>  删除文件或目录")
        print("     -r : 递归删除目录及内容")
        print("     -f : 强制删除，不提示，忽略不存在的文件")
        print("     -i : 交互式删除，每次删除前询问")
        print("     * : 匹配当前目录下所有非隐藏文件/文件夹")
        print()
        print(style("系统切换", "33;1"))
        print("  启用rust [参数...]      启动 Rust 子系统 main.exe")
        print("  启用cpp [参数...]       启动 C++ 子系统 main.exe")
        print("  返回                    从子系统根目录回到主系统")
        print()
        print(style("其他", "33;1"))
        print("  edit <文件>             使用系统默认文本编辑器（如记事本）打开")
        print("  start [路径]            用系统默认程序打开")
        print("  clear                   清屏")
        print("  help                    显示本帮助")
        print("  exit                    退出")
        print()
        print("提示: 名称含空格时请加引号，例如 open \"我的 文档\"。")
        print("      🛡️  所有操作都限制在 home 目录内。")
        print("      中文命令也可用，例如: 列表、打开、新建文件夹、删除、退出。")

    def cmd_exit(self, args: list[str]) -> None:
        if args:
            raise ShellError("用法: exit")
        self.ok("再见！")
        self.running = False

    # -- 参数解析 ----------------------------------------------------------

    @staticmethod
    def parse_flags(args: list[str], allowed: set[str]) -> tuple[set[str], list[str]]:
        flags: set[str] = set()
        rest: list[str] = []
        index = 0

        while index < len(args):
            argument = args[index]
            if argument == "--":
                rest.extend(args[index + 1 :])
                break
            if argument.startswith("-") and len(argument) > 1 and not argument.startswith("--"):
                for char in argument[1:]:
                    char = char.lower()
                    if char not in allowed:
                        raise ShellError(f"不支持的选项: -{char}")
                    flags.add(char)
            else:
                rest.append(argument)
            index += 1

        return flags, rest


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    configure_console()

    if "--version" in arguments:
        print(f"{APP_NAME} {APP_VERSION}")
        return 0

    if "--help" in arguments:
        print(f"{APP_NAME} {APP_VERSION} - 简易终端文件管理器")
        print(f"用法: python {Path(__file__).name}")
        print("启动后输入 help 查看可用命令。")
        return 0

    if arguments:
        print(f"未知参数: {' '.join(arguments)}", file=sys.stderr)
        print("可使用 --help 查看启动参数。", file=sys.stderr)
        return 2

    if not ROOT.is_dir():
        print(f"错误: 找不到 home 目录: {ROOT}", file=sys.stderr)
        return 1

    FileShell(ROOT).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())