@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONDONTWRITEBYTECODE=1"
set "APP=%~dp0.fileshell\fileshell.py"

if not exist "%APP%" (
    echo [HomeShell] Application file not found:
    echo   %APP%
    echo Make sure the .fileshell folder is complete.
    pause
    exit /b 1
)

set "PYTHON_EXE="
set "PYTHON_ARGS="

if exist "%~dp0bin\Python312\python.exe" (
    "%~dp0bin\Python312\python.exe" --version >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=%~dp0bin\Python312\python.exe"
)

python --version >nul 2>nul
if not defined PYTHON_EXE if not errorlevel 1 set "PYTHON_EXE=python"

if not defined PYTHON_EXE (
    py -3 --version >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_EXE=py"
        set "PYTHON_ARGS=-3"
    )
)

if not defined PYTHON_EXE (
    if exist "%USERPROFILE%\.dsh\dsh-runtimes" (
        for /d %%D in ("%USERPROFILE%\.dsh\dsh-runtimes\*") do (
            if not defined PYTHON_EXE if exist "%%D\dependencies\python\python.exe" set "PYTHON_EXE=%%D\dependencies\python\python.exe"
        )
    )
)

if not defined PYTHON_EXE (
    if exist "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" (
        set "PYTHON_EXE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
    )
)

if not defined PYTHON_EXE (
    echo [HomeShell] Python was not found.
    echo.
    echo Please install Python 3.10 or newer and enable "Add Python to PATH".
    echo Then double-click this file again.
    pause
    exit /b 1
)

title HomeShell
"%PYTHON_EXE%" %PYTHON_ARGS% "%APP%" %*
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo [HomeShell] Program exited with code %EXIT_CODE%.
    pause
)

endlocal
